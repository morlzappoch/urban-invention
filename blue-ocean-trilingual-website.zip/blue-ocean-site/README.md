# BLUE OCEAN — Public Landing Page

Trilingual static landing page for **Morley Moses Apooch — BLUE OCEAN**.

Languages: English, Russian, Simplified Chinese.

## Deploy

The included GitHub Actions workflow publishes the repository root through GitHub Pages. Keep the backend/API deployment separate because a static Pages site does not execute the Node.js backend.

## Local

Open `index.html` in a browser. No build step is required.
