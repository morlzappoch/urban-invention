/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

// eslint-disable-next-line no-restricted-imports
import '../../third_party/devtools-frontend/front_end/entrypoints/formatter_worker/formatter_worker-entrypoint.js';
